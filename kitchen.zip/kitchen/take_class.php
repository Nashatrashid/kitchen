<!DOCTYPE html>
<html lang="en">
<head>
<?php include 'link.php'; ?>
</head>
<body>

<div class="topnav">
  <?php include 'menu.php'; ?>
</div>

<div class="content">
  <h2>View Class</h2>
  <!-- Data Table for Class-->
  <div class="container">
    <table id="example" class="table table-striped table-bordered" style="width:100%">
      <thead>
          <tr>
              <th>Food Name</th>
              <th>Start Date</th>
              <th>End Date</th>
              <th>Action</th>
          </tr>
      </thead>
      <tbody>
        <?php
          $sql ="SELECT * FROM food inner join class using(foodId)";
          $stmt = $db->query($sql);
          $result = $stmt->fetchAll();
          foreach ($result as $row) { ?>
            <tr>
                <td><?php echo $row['foodName']; ?></td>
                <td><?php echo $row['classStartDate']; ?></td>
                <td><?php echo $row['classEndDate']; ?></td>
                <td>
                  <button type="button" class="btn btn-info btn-sm btn-block" data-toggle="modal" data-target="#myModal<?php echo $row['classId']; ?>">
                    View
                  </button>

                  <!-- Modal -->
                  <div class="modal fade" id="myModal<?php echo $row['classId']; ?>" role="dialog">
                    <div class="modal-dialog">
                      <!-- Modal Edit content-->
                      <div class="modal-content">
                          <div class="modal-header">
                            <h4 class="modal-title">Modal Header</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                          </div>
                          <div class="modal-body">
                            <div class="form-group">
                              <label>Notes</label>
                              <textarea name="classDescription" class="form-control" rows="10" cols="80" readonly><?php echo $row['classDescription']; ?></textarea>
                            </div>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                          </div>
                      </div>
                    </div>
                  </div>
                </td>
            </tr>
            <?php
          }
         ?>

      </tbody>
    </table>

  </div>
</div>

<div class="footer">
  <p>Footer</p>
</div>

</body>
</html>
