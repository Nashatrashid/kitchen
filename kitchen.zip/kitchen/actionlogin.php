<?php
  include 'connection.php';
  session_start();
  if (isset($_POST['username'])) {
    $username = $_POST['username'];
    $password = md5($_POST['password']);

    // Check If Client Exist
    $sqlClient = "SELECT * FROM user WHERE username = :user AND password = :pass";
    $stmt = $db->prepare($sqlClient);
    $stmt->execute(
      array(
        ':user' => $username,
        ':pass' => $password
      )
    );
    $result = $stmt->fetch(PDO::FETCH_ASSOC);


    if ($result > 0) {
      $_SESSION['role'] = $result['role'];
      echo $_SESSION['id'] = $selectClient['userId'];
      header('location: home.php');
    }else {
      header('location: index.php?error');
    }
  }
?>
