<?php
  include 'connection.php';

  if (isset($_POST['id'])) {
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $role = $_POST['role'];
    $id = $_POST['id'];

    $sql = "UPDATE user SET
      firstName=:firstName,
      lastName=:lastName,
      phone=:phone,
      address=:address,
      role=:role
      WHERE userId = :id";

    $stmt = $db->prepare($sql);
    $update = $stmt->execute(
      array(
        ':firstName' => $firstName,
        ':lastName' => $lastName,
        ':phone' => $phone,
        ':address' => $address,
        ':role' => $role,
        ':id' => $id
      )
    );

    if ($update) {
      header('location: view_user.php?edit');
    }
  }
?>
