<a href="home.php">Home</a>
<?php
session_start();
if (isset($_SESSION['role'])) {
  if ($_SESSION['role'] == 'chief') {?>
    <a href="view_class.php">View Class</a>
    <a href="view_food.php">View Food</a>
    <a href="view_user.php">View User</a>
  <?php }else{ ?>
    <a href="take_class.php">Take Class</a>
  <?php } ?>
  <a href="logout.php">Sign Out</a>
<?php
}else {
  header('location: index.php');
}
?>
