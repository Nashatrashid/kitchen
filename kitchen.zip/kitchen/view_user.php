<!DOCTYPE html>
<html lang="en">
<head>
<?php include 'link.php'; ?>
</head>
<body>

<div class="topnav">
  <?php include 'menu.php'; ?>
</div>

<div class="content">
  <h2>View User</h2>
  <!-- Data Table for User-->
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <button type="button" class="btn btn-primary btn-sm float-right" data-toggle="modal" data-target="#myModal">Add User</button>

        <!-- Modal -->
        <div class="modal fade" id="myModal" role="dialog">
          <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-header">
                <h4 class="modal-title">Modal Header</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
              </div>
              <form action="insert_user.php" method="post">
                <div class="modal-body">
                    <div class="form-group">
                      <label>First Name</label>
                      <input type="text" class="form-control" name="firstName" required>
                    </div>
                    <div class="form-group">
                      <label>Last Name</label>
                      <input type="text" class="form-control" name="lastName" required>
                    </div>
                    <div class="form-group">
                      <label>Phone Number</label>
                      <input type="text" class="form-control" name="phone" required>
                    </div>
                    <div class="form-group">
                      <label>Address</label>
                      <input type="text" class="form-control" name="address" required>
                    </div>
                    <div class="form-group">
                      <label>Username</label>
                      <input type="text" class="form-control" name="username" required>
                    </div>
                    <div class="form-group">
                      <label>Password</label>
                      <input type="text" class="form-control" name="password" required>
                    </div>
                    <div class="form-group">
                      <label>Role</label>
                      <select class="form-control" name="role" required>
                        <option value="">Select Role</option>
                        <option value="chief">Chief</option>
                        <option value="user">User</option>
                      </select>
                    </div>
                </div>
                <div class="modal-footer">
                  <input type="submit" class="btn btn-success" name="submit" value="Save User">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
              </form>
            </div>

          </div>
        </div>
      </div>
    </div>
    <table id="example" class="table table-striped table-bordered" style="width:100%">
      <thead>
          <tr>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Phone Number</th>
              <th>Address</th>
              <th>Status</th>
              <th>Role</th>
              <th>Action</th>
          </tr>
      </thead>
      <tbody>
        <?php
          include "connection.php";
          $sql ="SELECT * FROM user";
          $stmt = $db->query($sql);
          $result = $stmt->fetchAll();
          foreach ($result as $row) { ?>
            <tr>
                <td><?php echo $row['firstName']; ?></td>
                <td><?php echo $row['lastName']; ?></td>
                <td><?php echo $row['phone']; ?></td>
                <td><?php echo $row['address']; ?></td>
                <td><?php echo $row['status']; ?></td>
                <td><?php echo $row['role']; ?></td>
                <td>
                  <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#myModal<?php echo $row['userId']; ?>">
                    Edit User
                  </button>

                  <!-- Modal -->
                  <div class="modal fade" id="myModal<?php echo $row['userId']; ?>" role="dialog">
                    <div class="modal-dialog">
                      <!-- Modal Edit content-->
                      <div class="modal-content">
                        <form class="" action="edit_user.php" method="post">
                          <div class="modal-header">
                            <h4 class="modal-title">Modal Header</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                          </div>
                          <div class="modal-body">
                            <div class="form-group">
                              <label>First Name</label>
                              <input type="text" class="form-control" name="firstName" value="<?php echo $row['firstName']; ?>">
                            </div>
                            <div class="form-group">
                              <label>Last Name</label>
                              <input type="text" class="form-control" name="lastName" value="<?php echo $row['lastName']; ?>">
                            </div>
                            <div class="form-group">
                              <label>Phone Number</label>
                              <input type="text" class="form-control" name="phone" value="<?php echo $row['phone']; ?>">
                            </div>
                            <div class="form-group">
                              <label>Address</label>
                              <input type="text" class="form-control" name="address" value="<?php echo $row['address']; ?>">
                            </div>
                            <div class="form-group">
                              <label>Role</label>
                              <select class="form-control" name="role" required>
                                <option value="<?php echo $row['role']; ?>"><?php echo $row['role']; ?></option>
                                <option value="chief">Chief</option>
                                <option value="user">User</option>
                              </select>
                            </div>
                          </div>
                          <div class="modal-footer">
                            <input type="hidden" name="id" value="<?php echo $row['userId']; ?>">
                            <input type="submit" class="btn btn-primary" value="submit">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                  <a href="delete_user.php?id=<?php echo $row['userId']; ?>" onclick="return confirm('Do You Want To Delete?')" class="btn btn-sm btn-danger"> Delete</a>
                </td>
            </tr>
            <?php
          }
         ?>

      </tbody>
    </table>

  </div>
</div>

<div class="footer">
  <p>Footer</p>
</div>

</body>
</html>
