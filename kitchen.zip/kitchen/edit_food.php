<?php
  include 'connection.php';

  if (isset($_POST['id'])) {
    $foodName = $_POST['foodName'];
    $foodDescription = $_POST['foodDescription'];
    $foodStatus = $_POST['foodStatus'];
    $id = $_POST['id'];

    $sql = "UPDATE food SET
      foodName=:foodName,
      foodDescription=:foodDescription,
      foodStatus=:foodStatus
      WHERE foodId = :id";

    $stmt = $db->prepare($sql);
    $update = $stmt->execute(
      array(
        ':foodName' => $foodName,
        ':foodDescription' => $foodDescription,
        ':foodStatus' => $foodStatus,
        ':id' => $id
      )
    );

    if ($update) {
      header('location: view_food.php?edit');
    }
  }
?>
