<?php
  include 'connection.php';

  if (isset($_POST['foodId'])) {
    echo $classStartDate = $_POST['classStartDate'];
    echo '<br>'.$classEndDate = $_POST['classEndDate'];
    echo '<br>'.$classStatus = $_POST['classStatus'];
    echo '<br>'.$classDescription = $_POST['classDescription'];
    echo '<br>'.$foodId = $_POST['foodId'];
    echo '<br>'.$id = $_POST['id'];

    $sql = "UPDATE class SET
      foodId = :foodId,
      classStartDate = :classStartDate,
      classEndDate = :classEndDate,
      classDescription = :classDescription,
      classStatus = :classStatus,
      WHERE classId = :id";

    $stmt = $db->prepare($sql);
    $update = $stmt->execute(
      array(
        ':foodId' => $foodId,
        ':classStartDate' => $classStartDate,
        ':classEndDate' => $classEndDate,
        ':classDescription' => $classDescription,
        ':classStatus' => $classStatus,
        ':id' => $id
      )
    );

    if ($update) {
      header('location: view_class.php?edit');
    }else {
      echo "Try";
    }
  }
?>
