<?php
  include 'connection.php';

  if (isset($_POST['foodName'])) {
    $foodName = $_POST['foodName'];
    $foodDescription = $_POST['foodDescription'];
    $foodStatus = $_POST['foodStatus'];

    $sql = "INSERT INTO food (foodName, foodDescription, foodStatus)
    VALUES (:food_name,:food_description,:foodStatus)";

    $stmt = $db->prepare($sql);
    $insert = $stmt->execute(
      array(
        ':food_name' => $foodName,
        ':food_description' => $foodDescription,
        ':foodStatus' => $foodStatus
      )
    );

    if ($insert) {
      header('location: view_food.php?insert');
    }
  }
?>
