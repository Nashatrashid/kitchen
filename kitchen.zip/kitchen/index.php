<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/jquery.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
  </head>
  <body style="background-color: purple;">
    <div class="container-fluid">
      <div style="margin-top: 100px;">
        <div class="card" style="padding: 10px; width: 50%; margin: auto;">
          <form action="actionlogin.php" method="post" style="padding: 5px;">
            <div class="form-group">
              <label>Username</label>
              <input type="text" class="form-control" name="username" required>
            </div>
            <div class="form-group">
              <label>Password</label>
              <input type="password" class="form-control" name="password" required>
            </div>

            <div class="form-group">
              <input type="submit" class="btn btn-success btn-block" name="signin" value="Sign In">
            </div>

          </form>
        </div>
      </div>

    </div>
  </body>
</html>
