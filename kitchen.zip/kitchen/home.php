<!DOCTYPE html>
<html lang="en">
<head>
<?php include 'link.php'; ?>
</head>
<body>

<div class="topnav">
  <?php include 'menu.php'; ?>
</div>

<div class="content">
  <h2>Welcome <?php echo $_SESSION['role']; ?></h2>
  <p>Karibu Katika Darasa la Mapishi</p>
</div>

<div class="footer">
  <p class="text-center">Kitchen Class</p>
</div>

</body>
</html>
