<?php
  include 'connection.php';

  if (isset($_POST['firstName'])) {
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $status = 'active';
    $role = $_POST['role'];

    $sql = "INSERT INTO user( firstName, lastName, phone, address, status, username, password, role)
    VALUES (:f_name,:l_name,:phone,:address,:status, :username, :password,:role)";

    $stmt = $db->prepare($sql);
    $insert = $stmt->execute(
      array(
        ':f_name' => $firstName,
        ':l_name' => $lastName,
        ':phone' => $phone,
        ':address' => $address,
        ':status' => $status,
        ':username' => $username,
        ':password' => $password,
        ':role' => $role
      )
    );

    if ($insert) {
      header('location: view_user.php?insert');
    }
  }
?>
