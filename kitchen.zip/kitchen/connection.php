<?php

try {
    $db = new PDO( 'mysql:host=localhost;dbname=kitchen;charset=utf8', 'root', '' );
}

catch(Exception $e) {
    echo "An error has occurred";
}

?>
