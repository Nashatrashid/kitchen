<?php include 'connection.php'; ?>
<title>Kitchen Class</title>
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
<script src="bootstrap/js/jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>

<!-- DataTable -->
<script src="datatable/js/jquery-3.5.1.js"></script>
<script src="datatable/js/jquery.dataTables.min.js"></script>
<script src="datatable/js/dataTables.bootstrap4.min.js"></script>
<!-- Layout -->
<style>
  * {
    box-sizing: border-box;
    font-family: Arial, Helvetica, sans-serif;
  }

  body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
  }

  .topnav {
    overflow: hidden;
    background-color: #535;
  }

  .topnav a {
    float: left;
    display: block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }

  .topnav a:hover {
    background-color: #ddd;
    color: black;
  }

  .content {
    background-color: white;
    padding: 10px;
    min-height: 200px;
  }

  .footer {
    background-color: #535;
    padding: 10px;
    color: white;
  }
</style>
<script>
$(document).ready(function() {
  $('#example').DataTable();
} );
</script>
