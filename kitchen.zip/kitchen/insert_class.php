<?php
  include 'connection.php';

  if (isset($_POST['classStartDate'])) {
    $classStartDate = $_POST['classStartDate'];
    $classEndDate = $_POST['classEndDate'];
    $classDescription = $_POST['classDescription'];
    $classStatus = $_POST['classStatus'];
    $foodId = $_POST['foodId'];

    $sql = "INSERT INTO class (foodId, classStartDate, classEndDate, classDescription, classStatus)
    VALUES (:f_id, :c_start, :c_end, :c_desc, :c_status)";

    $stmt = $db->prepare($sql);
    $insert = $stmt->execute(
      array(
        ':f_id' => $foodId,
        ':c_start' => $classStartDate,
        ':c_end' => $classEndDate,
        ':c_desc' => $classDescription,
        ':c_status' => $classStatus
      )
    );

    if ($insert) {
      header('location: view_class.php?insert');
    }
    else {
      echo "Nje";
    }
  }
?>
