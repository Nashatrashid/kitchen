<?php
  include 'connection.php';

  if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "DELETE FROM food WHERE foodId = :id";

    $stmt = $db->prepare($sql);
    $delete = $stmt->execute(array(':id' => $id));

    if ($delete) {
      header('location: view_food.php?delete');
    }
  }
?>
